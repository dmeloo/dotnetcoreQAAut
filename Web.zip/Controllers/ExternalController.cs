﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Web.Controllers
{
//    [Route("api/[controller]")]
  //  [ApiController]
    public class ExternalController : Controller
    {
    }
}
